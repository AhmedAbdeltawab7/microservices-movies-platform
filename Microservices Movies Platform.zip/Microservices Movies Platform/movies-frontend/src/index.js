function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>🎬 Movies Platform</h1>
      <p>Frontend connected via API Gateway</p>
    </div>
  );
}

export default App;
