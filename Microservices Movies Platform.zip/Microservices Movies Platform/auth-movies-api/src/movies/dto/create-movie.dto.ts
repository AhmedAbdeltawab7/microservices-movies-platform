export class CreateMovieDto {
  title: string;
  director?: string;
  year?: number;
  genre?: string;
}
