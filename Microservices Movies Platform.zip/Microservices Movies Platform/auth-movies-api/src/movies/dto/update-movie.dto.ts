export class UpdateMovieDto {
  title?: string;
  director?: string;
  year?: number;
  genre?: string;
}
